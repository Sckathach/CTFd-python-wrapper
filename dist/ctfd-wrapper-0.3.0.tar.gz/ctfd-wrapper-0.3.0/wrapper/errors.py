class HiddenChallengeError(Exception):
    pass


class RequestError(Exception):
    pass


class CTFdAPIError(Exception):
    pass
